import { Entity, Column } from "typeorm"
import { BaseEntity } from "./BaseEntity"

@Entity("suppliers")
export class Supplier extends BaseEntity {

    @Column({
        type: 'varchar',
        length: 255
    })
    name: string
    @Column({
        type: 'varchar',
        length: 255
    })
    email: string
    @Column({
        type: 'varchar',
        length: 255
    })
    contact: string
    @Column({
        type: 'varchar',
        length: 20
    })
    cnpj: string
    @Column({
        type: 'varchar',
        length: 20,
        nullable: true,
        default: null,
    })
    phone?: string
    @Column({
        type: 'varchar',
        length: 20,
        nullable: true,
        default: null,
    })
    address?: string
    @Column({
        type: 'boolean'
    })
    status: boolean
}