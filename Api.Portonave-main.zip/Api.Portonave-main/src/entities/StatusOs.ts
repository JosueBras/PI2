import { Entity, Column } from "typeorm"
import { BaseEntity } from "./BaseEntity"

@Entity("statusOs")
export class StatusOs extends BaseEntity {

    @Column({
        type: 'varchar',
        length: 255
    })
    description: string
}