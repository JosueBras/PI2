import { Entity, Column, OneToOne, JoinColumn, CreateDateColumn } from "typeorm"
import { BaseEntity } from "./BaseEntity"
import { StatusOs } from "./StatusOs"
import { Equipment } from "./Equipment"
import { Sector } from "./Sector"

@Entity("os")
export class OS extends BaseEntity {

    @Column({
        type: 'varchar'
    })
    statusOsId: string
    @OneToOne(() => StatusOs)
    @JoinColumn()
    statusOs: StatusOs

    @Column({
        type: 'varchar'
    })
    equipmentId: string
    @OneToOne(() => Equipment)
    @JoinColumn()
    equipment: Equipment

    @Column({
        type: 'varchar'
    })
    sectorId: string
    @OneToOne(() => Sector)
    @JoinColumn()
    sector: Sector

    @Column({
        type: 'varchar',
        length: 255
    })
    failure: string

    @Column({
        type: 'varchar',
        length: 255
    })
    internalCall: string

    @Column({
        type: 'boolean',
        default: null,
        nullable: true,
    })
    isAntenna?: boolean

    @Column({
        type: 'boolean',
        default: null,
        nullable: true,
    })
    isBattery?: boolean

    @Column({
        type: 'boolean',
        default: null,
        nullable: true,
    })
    isCover?: boolean

    @Column({
        type: 'boolean',
        default: null,
        nullable: true,
    })
    isCapa?: boolean

    @Column({
        type: 'varchar',
        length: 255
    })
    numberOs: string

    @Column({
        type: 'varchar',
        length: 255
    })
    numberNF: string

    @CreateDateColumn({ type: 'timestamp' })
    data: Date

    @Column({
        type: 'varchar',
        length: 255
    })
    sdcv: string

    @Column({
        type: 'varchar',
        length: 255,
        default: null,
        nullable: true,
    })
    observation?: string
}