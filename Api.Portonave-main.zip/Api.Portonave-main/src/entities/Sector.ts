import { Entity, Column } from "typeorm"
import { BaseEntity } from "./BaseEntity"

@Entity("sectors")
export class Sector extends BaseEntity {

    @Column({
        type: 'varchar',
        length: 255
    })
    description: string
}