import { Entity, Column } from "typeorm"
import { BaseEntity } from "./BaseEntity"

@Entity("users")
export class User extends BaseEntity {

    @Column({
        type: 'varchar',
        length: 255
    })
    name: string
    @Column({
        type: 'varchar',
        length: 255
    })
    email: string
    @Column({
        type: 'varchar',
        length: 255
    })
    password: string
    @Column({
        type: 'varchar',
        length: 20,
        nullable: true,
        default: null,
    })
    phone?: string | null
    @Column({
        type: 'int',
    })
    profile: number
    @Column({
        type: 'boolean'
    })
    status: boolean
}