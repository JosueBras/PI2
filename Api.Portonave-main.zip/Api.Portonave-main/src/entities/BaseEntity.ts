import { Entity, PrimaryGeneratedColumn, CreateDateColumn } from 'typeorm';
import { v4 as uuidv4 } from 'uuid'

@Entity()
export class BaseEntity {
    @PrimaryGeneratedColumn()
    id: string;

    @CreateDateColumn({ type: 'timestamp'})
    dtCreation: Date;

    constructor(){
        if(!this.id){
            this.id = uuidv4();
        }
    }
}
