import { Entity, Column ,CreateDateColumn} from "typeorm"
import { BaseEntity } from "./BaseEntity"

@Entity("equipments")
export class Equipment extends BaseEntity {

    @Column({
        type: 'int'
    })
    type: number

    @Column({
        type: "varchar",
        length: 100
    })
    patrimony: string

    @Column({
        type: "varchar",
        length: 100
    })
    model: string

    @Column({
        type: "varchar",
        length: 100
    })
    serialNumber: string

    @Column({
        type: "varchar",
        length: 100
    })
    //centro de custo
    cost: string

    @Column({
        type: "varchar",
        length: 100
    })
    //Data de aquisição
    data: string

    @Column({
        type: "varchar",
        length: 100
    })
    localCode: string

    @CreateDateColumn({ type: 'timestamp'})
    lowDate?: Date;

    @Column({
        type: "varchar",
        length: 100
    })
    location: string

    @Column({
        type: 'boolean'
    })
    status: boolean
}