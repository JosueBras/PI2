import jwt, { Secret, JwtPayload } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";

export const SECRET_KEY: Secret = "32518776-0a7b-47ff-8813-d86b1d2f0e99";

export interface CustomRequest extends Request {
  token: string | JwtPayload;
}

interface jwtPayload {
  id: string;
  name: string;
  profile: number;
}

// Perfil de usuário
// 0 = Admin
// 1 = Técnico
// 2 = Usuário comum

export const auth = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = req.header("Authorization")?.replace("Bearer ", "");
    if (!token) {
      throw new Error();
    }

    const jwtPayload = payloadJWT(req);
    const url = req.originalUrl.replace('/api/','');
    const action = url.split("-")[0];
    const entity = url.split("-")[1];

    if(typeof jwtPayload !== 'string' && jwtPayload.profile != 0){
      
      if (action === 'create' && (entity === 'user' || entity === 'supplier')) {
        return res.status(401).send({ message: "Usuário não autorizado!" });
      }

      if(action === 'delete'){
        return res.status(401).send({ message: "Usuário não autorizado!" });
      }
    }


    const decoded = jwt.verify(token, SECRET_KEY);
    (req as CustomRequest).token = decoded;

    next();
  } catch (err) {
    return res.status(401).send({ message: "Usuário não autenticado!" });
  }
};

export function payloadJWT(req: Request): string | undefined | jwtPayload {
  const token = req.header("Authorization")?.replace("Bearer ", "");

  if (!token) return undefined;

  const payload = jwt.verify(token, SECRET_KEY);

  if (!payload) return undefined;

  return payload as jwtPayload;
}
