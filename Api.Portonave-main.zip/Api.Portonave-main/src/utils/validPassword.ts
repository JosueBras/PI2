export function validPassword(password: string) : boolean{

    const PasswordRegex = /^(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\S+$).{8,}$/;

    return PasswordRegex.test(password);
}