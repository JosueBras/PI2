import 'reflect-metadata'
import express from 'express'
import './database'
import { auth } from './middleware/auth'
import { userController } from './router/UserRouter';
import { LoginController } from './router/LoginRouter';
import { SupplierController } from './router/SupplierRouter';
import { EquipmetController } from './router/EquipmentRouter';
import { SectorController } from './router/SectorRouter';
import { StatusController } from './router/StatusOsRouter';
import { OsController } from './router/OsRouter';
import cors from "cors"

const app = express();

const userControllerServer = new userController();
const supplierContollerServer = new SupplierController();
const equipmetsContrllerServer = new EquipmetController();
const sectorsContrllerServer = new SectorController();
const statusContrllerServer = new StatusController();
const osContrllerServer = new OsController();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(cors({origin: 'http://localhost:5173'}));

app.post("/api/login-user", new LoginController().login);

app.post("/api/create-user", auth, userControllerServer.create);
app.put("/api/update-user", auth, userControllerServer.update);
app.delete("/api/delete-user/:id", auth, userControllerServer.delete);
app.get("/api/get-user/:id", auth, userControllerServer.get);
app.get("/api/all-user", auth, userControllerServer.getAll);
app.post("/api/repassword-user", auth, userControllerServer.replacePassword);

app.post("/api/create-supplier", auth, supplierContollerServer.create);
app.put("/api/update-supplier", auth, supplierContollerServer.update);
app.get("/api/all-supplier", auth, supplierContollerServer.allSuplier);
app.get("/api/get-supplier/:id", auth, supplierContollerServer.get);
app.delete("/api/delete-supplier/:id", auth, supplierContollerServer.delete);

app.get("/api/all-equipmets", auth, equipmetsContrllerServer.getAll);

app.get("/api/all-sectors", auth, sectorsContrllerServer.getAll);

app.get("/api/all-status_os", auth, statusContrllerServer.getAll);

app.get("/api/all-os", auth, osContrllerServer.getAll);
app.post("/api/create-os", auth, osContrllerServer.create);

app.listen(3000, () => { console.log("server on") })