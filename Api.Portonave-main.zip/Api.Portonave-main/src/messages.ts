export const messageErrorGeneric =
  "Ocorreu um erro interno, tente novamente mais tarde!";
export const messageCreateGeneric = "Registro criado com sucesso!";
export const messageUpdateGeneric = "Registro atualizado com sucesso!";
export const messageDeleteGeneric = "Registro excluído com sucesso!";
