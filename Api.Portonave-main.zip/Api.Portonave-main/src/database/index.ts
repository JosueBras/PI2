import { DataSource } from "typeorm"
import { AllEntities } from "./Config";

export const AppDataSource = new DataSource({
    type: "mysql",
    host: "localhost",
    port: 3306,
    username: "root",
    password: "password",
    database: "portonave",
    entities: [...AllEntities],
})

AppDataSource.initialize().then(async () => {
    console.log("Conexão com db Ok...");
}).catch((error) => console.log(error));