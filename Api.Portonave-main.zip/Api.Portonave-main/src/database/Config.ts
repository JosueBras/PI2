import { User } from "../entities/Users"
import { Supplier } from "../entities/Supplier"
import { Equipment } from "../entities/Equipment";
import { Sector } from "../entities/Sector";
import { StatusOs } from "../entities/StatusOs";
import { OS } from "../entities/OS";

export const AllEntities = [
    User,
    Supplier,
    Equipment,
    Sector,
    StatusOs,
    OS
]