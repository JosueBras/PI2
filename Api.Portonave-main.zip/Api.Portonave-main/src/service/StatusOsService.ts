import { AppDataSource } from "../database";
import { StatusOs } from "../entities/StatusOs";

const repo = AppDataSource.getRepository(StatusOs);

export async function GetAllStatusOs(): Promise<StatusOs [] | undefined>{

    const statusOs = await repo.find();

    if (!statusOs) return undefined;

    return statusOs;
}