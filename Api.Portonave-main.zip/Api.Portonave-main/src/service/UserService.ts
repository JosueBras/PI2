import { AppDataSource } from "../database";
import { User } from "../entities/Users";
import bcrypt from "bcrypt";
import { validPassword } from "../utils/validPassword";
import { createUser, replacePassword, updateUser } from "./interfaces/user";

const repo = AppDataSource.getRepository(User);

export async function CreateUserService(
  userCreate: createUser
): Promise<boolean | string> {
  const userValidate = await repo
    .findOneBy({ email: userCreate.email });

  if (userValidate)
    return `Usuário com email : ${userCreate.email} já se encontra cadastrado!`;

  if (userCreate.password != userCreate.rePassword)
    return "As senha não conferem!";

  if (!validPassword(userCreate.password))
    return "Senha muito fraca, utilize uma senha com no mínimo 8 caracteres, uma letra maiúscula e uma minúscula, e um caracter especial!";

  const user = new User();

  user.name = userCreate.name;
  user.email = userCreate.email;
  user.password = bcrypt.hashSync(userCreate.password, 10);
  user.profile = userCreate.profile;
  user.phone = userCreate.phone;
  user.status = true;

  await repo.manager.save(user);

  return true;
}

export async function UpdateUserService(
  userUpdate: updateUser
): Promise<boolean | string> {
  const user = await repo.findOneBy({ id: userUpdate.id });

  if (!user) return "Usuário não encontrado!";

  user.email = userUpdate.email;
  user.phone = userUpdate.phone;
  user.profile = userUpdate.profile;
  user.status = userUpdate.status;

  await repo.manager.save(user);

  return true;
}

export async function DeleteUserService(id: string): Promise<boolean> {

  const user = await repo.findOneBy({ id });

  if (!user) return false;

  repo.remove(user);

  return true;
}

export async function GetUserServiceById(id: string): Promise<User | undefined> {

  const user = await repo.findOneBy({ id });

  if (!user) return undefined;

  return user;
}

export async function GetAllUser(search?: string): Promise<User[] | undefined> {

  let user = [];

  if (search) {
    user = await repo.createQueryBuilder("users")
      .where("users.name like :name", { name: `%${search}%` })
      .getMany();
  } else {
    user = await repo.find();
  }

  if (!user) return undefined;

  return user;
}

export async function ToReplacePassword(id: string, newPassword: replacePassword): Promise<string> {

  const user = await repo.findOneBy({ id });

  if (!user) return "Usuário não localizado";

  const passwordMatches = await bcrypt.compare(newPassword.password, user.password);

  if (!passwordMatches) return "Senha incorreta!";
  if (newPassword.newPassword != newPassword.reNewPassword) return "As senhas não conferem!"
  if (!validPassword(newPassword.newPassword))
    return "Senha muito fraca, utilize uma senha com no mínimo 8 caracteres, uma letra maiúscula e uma minúscula, e um caracter especial!";

  user.password = bcrypt.hashSync(newPassword.newPassword, 10);

  await repo.manager.save(user);

  return "Ok";
}
