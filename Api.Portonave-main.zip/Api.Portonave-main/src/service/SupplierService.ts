import { AppDataSource } from "../database";
import { Supplier } from "../entities/Supplier";
import { messageCreateGeneric, messageUpdateGeneric } from "../messages";
import { createSupplier, updateSupplier } from "./interfaces/supplier";

const repo = AppDataSource.getRepository(Supplier);

export async function CreateSupplier(supplierCreate: createSupplier): Promise<string> {

    var supplierValidate = await repo.findOneBy({ cnpj: supplierCreate.cnpj })

    if (supplierValidate) return `Fornecedor com cnpj : ${supplierValidate.cnpj} já se encontra cadastrado!`;

    const supplier = new Supplier();

    supplier.name = supplierCreate.name;
    supplier.email = supplierCreate.email;
    supplier.cnpj = supplierCreate.cnpj;
    supplier.contact = supplierCreate.contact;
    supplier.address = supplierCreate.address;
    supplier.phone = supplierCreate.phone;
    supplier.status = true;

    await repo.manager.save(supplier);

    return messageCreateGeneric;
}

export async function UpdateSupplier(supplierUpdate: updateSupplier): Promise<string | undefined> {

    const supplier = await repo.findOneBy({ id: supplierUpdate.id });

    if (!supplier) return undefined;

    supplier.email = supplierUpdate.email;
    supplier.cnpj = supplierUpdate.cnpj;
    supplier.contact = supplierUpdate.contact;
    supplier.address = supplierUpdate.address;
    supplier.phone = supplierUpdate.phone;
    supplier.status = supplierUpdate.status;

    await repo.manager.save(supplier);

    return messageUpdateGeneric;
}

export async function GetAllSupplier(search?: string): Promise<Supplier[] | undefined> {

    var suppliers = [];

    if (search) {
        suppliers = await repo.createQueryBuilder("supplier")
            .where("supplier.name like :name", { name: `%${search}%` })
            .getMany();
    } else {
        suppliers = await repo.find();
    }

    if (!suppliers) return undefined;

    return suppliers;
}

export async function GetSupplierById(id: string): Promise<Supplier | undefined> {

    var supplier = await repo.findOneBy({ id });

    if (!supplier) return undefined;

    return supplier;
}

export async function DeleteSupplierService(id: string): Promise<boolean> {

    const supplier = await repo.findOneBy({ id });

    if (!supplier) return false;

    repo.remove(supplier);

    return true;
}