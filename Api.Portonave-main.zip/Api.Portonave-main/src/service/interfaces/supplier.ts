export interface createSupplier {
    name: string,
    contact: string,
    email: string,
    phone?: string,
    cnpj: string,
    address?: string
}

export interface updateSupplier {
    id: string,
    contact: string,
    email: string,
    phone?: string,
    cnpj: string,
    address?: string,
    status: boolean
}