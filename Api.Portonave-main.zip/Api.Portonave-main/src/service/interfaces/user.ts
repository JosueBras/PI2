export interface createUser {
  name: string;
  email: string;
  password: string;
  phone?: string;
  profile: number;
  rePassword: string;
}

export interface updateUser {
  id: string;
  email: string;
  phone?: string;
  profile: number;
  status: boolean;
}

export interface replacePassword {
  password: string;
  newPassword: string;
  reNewPassword: string;
}
