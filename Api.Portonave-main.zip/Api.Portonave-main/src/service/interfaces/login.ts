export interface Login {
  email: string;
  password: string;
}

export interface UserResponse {
  name: string;
  phone?: string;
  profile: number;
}

export interface RepoponseLogin {
  user: UserResponse;
  token: string;
}
