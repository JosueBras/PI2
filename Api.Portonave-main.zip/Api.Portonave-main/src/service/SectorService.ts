import { AppDataSource } from "../database";
import { Sector } from "../entities/Sector";

const repo = AppDataSource.getRepository(Sector);

export async function GetAllSectors(): Promise<Sector [] | undefined>{

    const sectors = await repo.find();

    if (!sectors) return undefined;

    return sectors;
}