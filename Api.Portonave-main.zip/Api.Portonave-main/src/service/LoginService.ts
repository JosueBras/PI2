import { AppDataSource } from "../database";
import bcrypt from "bcrypt";
import { User } from "../entities/Users";
import jwt from "jsonwebtoken";
import { SECRET_KEY } from "../middleware/auth";
import { Login, RepoponseLogin } from "./interfaces/login";

const repo = AppDataSource;

export async function LoginService(
  login: Login
): Promise<RepoponseLogin | undefined> {
  const user = await repo
    .getRepository(User)
    .findOneBy({ email: login.email, status: true });

  if (!user) return undefined;

  const passwordMatches = await bcrypt.compare(login.password, user.password);

  if (passwordMatches) {
    const token = jwt.sign(
      { id: user.id, name: user.name, profile: user.profile },
      SECRET_KEY,
      {
        expiresIn: "1 days",
      }
    );

    const responseLogin: RepoponseLogin = {
      user: {
        name: user.name,
        profile: user.profile,
        phone: user.phone,
      },
      token: token,
    };

    return responseLogin;
  } else {
    return undefined;
  }
}
