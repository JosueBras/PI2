import { AppDataSource } from "../database";
import { Equipment } from "../entities/Equipment";

const repo = AppDataSource.getRepository(Equipment);

export async function GetAllEquipments(): Promise<Equipment [] | undefined>{

    const equipments = await repo.find();

    if (!equipments) return undefined;

    return equipments;
}