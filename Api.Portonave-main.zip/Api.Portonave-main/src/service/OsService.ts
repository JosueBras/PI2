import { AppDataSource } from "../database";
import { OS } from "../entities/OS";
import { osCreate } from "./interfaces/os";

const repo = AppDataSource.getRepository(OS);

export async function GetAllOs(): Promise<OS[] | undefined> {

    const oss = await repo.find({
        relations: {
            sector: true,
            statusOs: true,
            equipment: true
        }
    });

    if (!oss) return undefined;

    return oss;
}

export async function CreateOs(osCreateParam: osCreate): Promise<boolean> {
    
    let os = new OS();

    os.statusOsId = osCreateParam.statusOsId;
    os.equipmentId = osCreateParam.equipmentId;
    os.sectorId = osCreateParam.sectorId;
    os.failure = osCreateParam.failure;
    os.internalCall = osCreateParam.internalCall;
    os.isAntenna = osCreateParam.isAntenna;
    os.isBattery = osCreateParam.isBattery;
    os.isCover = osCreateParam.isCover;
    os.isCapa = osCreateParam.isCapa;
    os.numberOs = osCreateParam.numberOs;
    os.numberNF = osCreateParam.numberNF;
    os.observation = osCreateParam.observation;
    os.sdcv = osCreateParam.sdcv;
    os.data = osCreateParam.data;

    await repo.manager.save(os)

    return true;
}