import { Request, Response } from "express";
import { messageCreateGeneric, messageErrorGeneric } from "../messages";
import { CreateOs, GetAllOs } from "../service/OsService";

export class OsController {
    async getAll(req: Request, res: Response) {
        try {
            const os = await GetAllOs();

            if (!os) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(os);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }

    async create(req: Request, res: Response) {
        try {

            const osBody = req.body;

            if (!osBody) return res.status(404).send({ message: messageErrorGeneric });

            const result = await CreateOs(osBody);

            if (!result) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send({ message: messageCreateGeneric });

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }
}