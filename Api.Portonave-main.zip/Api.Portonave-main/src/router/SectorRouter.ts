import { Request, Response } from "express";
import { messageErrorGeneric } from "../messages";
import { GetAllSectors } from "../service/SectorService";

export class SectorController {
    async getAll(req: Request, res: Response) {
        try {
            const sectors = await GetAllSectors();

            if (!sectors) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(sectors);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }
}