import { Request, Response } from "express";
import { messageErrorGeneric } from "../messages";
import { GetAllStatusOs } from "../service/StatusOsService";

export class StatusController {
    async getAll(req: Request, res: Response) {
        try {
            const status = await GetAllStatusOs();

            if (!status) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(status);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }
}