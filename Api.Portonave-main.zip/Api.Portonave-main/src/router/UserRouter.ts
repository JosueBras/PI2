import { Request, Response } from "express";
import {
  CreateUserService,
  DeleteUserService,
  GetAllUser,
  GetUserServiceById,
  ToReplacePassword,
  UpdateUserService,
} from "../service/UserService";
import { createUser, replacePassword, updateUser } from "../service/interfaces/user";
import { messageErrorGeneric, messageCreateGeneric, messageUpdateGeneric, messageDeleteGeneric } from "../messages";
import { payloadJWT } from "../middleware/auth";

export class userController {
  async create(req: Request, res: Response) {
    try {
      const userCreate: createUser = req.body;
      const result = await CreateUserService(userCreate);

      if (typeof result === "string")
        return res.status(404).send({ message: result });

      if (!result) return res.status(404).send({ message: messageErrorGeneric });

      return res
        .status(201)
        .send({ message: messageCreateGeneric });
    } catch (error: any) {
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }

  async update(req: Request, res: Response) {
    try {
      const userUpdate: updateUser = req.body;

      const result = await UpdateUserService(userUpdate);
      if (typeof result === "string")
        return res.status(404).send({ message: result });

      if (!result) return res.status(404).send({ message: messageErrorGeneric });

      return res
        .status(200)
        .send({ message: messageUpdateGeneric });
    } catch (error: any) {
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }

  async delete(req: Request, res: Response) {
    try {

      const id = req.params.id;

      if (!id) return res.status(404).send({ message: messageErrorGeneric });

      const result = await DeleteUserService(id as string);

      if (!result) return res.status(404).send({ message: messageErrorGeneric });

      return res
        .status(200)
        .send({ message: messageDeleteGeneric });

    } catch (error: any) {
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }

  async get(req: Request, res: Response) {
    try {

      const id = req.params.id;

      if (!id) return res.status(404).send({ message: messageErrorGeneric });

      const user = await GetUserServiceById(id);

      if (!user) return res.status(404).send({ message: messageErrorGeneric });

      user.password = undefined;

      return res.status(200).send( user );

    } catch (error: any) {
      console.log(error)
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }

  async getAll(req: Request, res: Response) {
    try {

      const search = req.query.search;

      const users = await GetAllUser(search as string);

      if (!users) return res.status(404).send({ message: messageErrorGeneric });

      users.forEach(user => {
        user.password = undefined;
      })

      return res.status(200).send(users);

    } catch (error: any) {
      console.log(error)
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }

  async replacePassword(req: Request, res: Response) {
    try {

      const newPassword: replacePassword = req.body;

      const payload = payloadJWT(req);

      if (typeof payload != 'string') {

        const result = await ToReplacePassword(payload.id, newPassword);

        if (result != 'Ok') return res.status(404).send({ message: result });

        return res.status(200).send({ message: 'Senha alterada com sucesso!' });
      }

    } catch (error: any) {
      console.log(error)
      return res.status(404).send({ message: messageErrorGeneric });
    }
  }
}
