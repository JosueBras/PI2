import { Request, Response } from "express";
import { LoginService } from "../service/LoginService";

const error = "E-mail ou senha inválidos!";

export class LoginController {
  async login(req: Request, res: Response) {
    try {
      const login = req.body;

      if (!login) return res.status(404).send({ message: error });

      const loginResponse = await LoginService(login);

      if (loginResponse === undefined)
        return res.status(401).send({ message: error });

      return res.status(200).send(loginResponse);
    } catch (error: any) {
      return res.status(404).send({ message: error });
    }
  }
}
