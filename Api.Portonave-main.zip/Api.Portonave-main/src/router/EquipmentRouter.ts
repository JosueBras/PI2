import { Request, Response } from "express";
import { GetAllEquipments } from "../service/EquipmentService";
import { messageErrorGeneric } from "../messages";

export class EquipmetController {
    async getAll(req: Request, res: Response) {
        try {

            const equipmets = await GetAllEquipments();

            if (!equipmets) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(equipmets);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }
}