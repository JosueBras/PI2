import { Request, Response } from "express";
import { messageDeleteGeneric, messageErrorGeneric } from "../messages";
import { createSupplier, updateSupplier } from "../service/interfaces/supplier";
import { CreateSupplier, DeleteSupplierService, GetAllSupplier, GetSupplierById, UpdateSupplier } from "../service/SupplierService";

export class SupplierController {
    async create(req: Request, res: Response) {
        try {

            const supplierCreate: createSupplier = req.body;
            const result = await CreateSupplier(supplierCreate);

            return res.status(200).send({ message: result });
        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }

    async update(req: Request, res: Response) {
        try {

            const supplierUpdate: updateSupplier = req.body;
            const result = await UpdateSupplier(supplierUpdate);

            if (!result) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send({ message: result });
        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }

    async allSuplier(req: Request, res: Response) {
        try {
            const search = req.query.search;

            const result = await GetAllSupplier(search as string);

            if (!result) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(result);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }

    async get(req: Request, res: Response) {
        try {

            const id = req.params.id;

            if (!id) return res.status(404).send({ message: messageErrorGeneric });

            const supplier = await GetSupplierById(id);

            if (!supplier) return res.status(404).send({ message: messageErrorGeneric });

            return res.status(200).send(supplier);

        } catch (error: any) {
            console.log(error)
            return res.status(404).send({ message: messageErrorGeneric });
        }
    }

    async delete(req: Request, res: Response) {
        try {
    
          const id = req.params.id;
    
          if (!id) return res.status(404).send({ message: messageErrorGeneric });
    
          const result = await DeleteSupplierService(id as string);
    
          if (!result) return res.status(404).send({ message: messageErrorGeneric });
    
          return res
            .status(200)
            .send({ message: messageDeleteGeneric });
    
        } catch (error: any) {
          return res.status(404).send({ message: messageErrorGeneric });
        }
      }
}